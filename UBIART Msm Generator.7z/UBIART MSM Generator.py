import json
import os
from tkinter import filedialog
import tkinter as tk

def generate_files_from_json(json_data, output_dir):
    # Verifica se o diretório de saída existe, se não, cria
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for item in json_data:
        name = item.get('name')
        if name:
            # Cria um arquivo com o nome e a estrutura fornecidos
            with open(os.path.join(output_dir, name + '.msm'), 'wb') as file:
                file.write(item_structure())

def item_structure():
    # Retorna a estrutura do item em bytes
    return bytes.fromhex("00 00 00 01 00 00 00 07 67 65 6E 65 72 69 63 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 47 65 6E 65 72 69 63 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 41 63 63 5F 44 65 76 5F 44 69 72 5F 4E 50 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 3F 26 F3 00 3F 8C CC CD 40 60 00 00 3F A6 66 66 3D CC CC CD 21 1C 00 00 00 00 00 00 00 00 00 02 00 00 00 23 00 00 00 02 00 00 00 00 BF 7C D3 11 3F 75 5D 58 3F D6 69 2C BF 8E 87 E3 BF 97 0C 61 40 0F 2D 22 C0 16 02 6F 3F 76 5E 60 3F 82 B8 40 BF 14 C4 97 BF 22 AE 90 3E AC 6A CB 3C 46 DF 16 3F 3E 7F 1B BE 0C CE 78 BE 99 43 1F 3A AD AC F8 BF 38 FB A1 3F AD 5E 0E BF 57 B1 84 40 6A 49 D5 3F E2 1B 11 3F DC 5F E3 3F DE 8D 84 3F CE 02 13 3F D2 05 FA 3F EA 4D 43 3F A6 9A DF 41 D3 61 00 41 C9 1A 25 41 CD 1A 78 41 D4 32 14 41 C6 33 98 41 C1 F7 FD 41 B7 ED F5 3B 9A 71 0F 3B B6 58 56 3B CA 7B CC 3B 7A AF D6 3B AF 2E 6B 3B F4 26 CD 3B BB 9E 2A 3B 90 AD 7B 3B ED A8 ED 3C 1F 13 40 3B 8C F2 26 3B FB 0E 4C 3C 21 15 0E 3B 81 7C AB 3C 37 AB B4 3C 6A 6D 0F 3C 62 B0 B8 3B E5 31 20 3C 31 45 B3 3C A1 60 E9 3C 20 07 67 3F AC 45 BA 3F E9 D0 49 3F C2 BA 6E 3F C0 C4 FF 40 14 F2 08 3F 89 68 F3 3F DD 43 DA 3B 42 BA B6 3B 90 A1 B5 3B 32 E3 F5 3B 1F C1 19 3B 60 9F 43 3B 41 05 5D 3B 45 7A 21 3F D4 48 18 41 C8 D7 09")



def select_json_files(num_jsons):
    root = tk.Tk()
    root.withdraw()  # Oculta a janela principal

    json_paths = []
    for i in range(num_jsons):
        # Abre a janela de seleção de arquivo
        file_path = filedialog.askopenfilename(title=f"Selecione o arquivo JSON {i+1}", filetypes=[("JSON files", "*.json")])
        if file_path:
            json_paths.append(file_path)
        else:
            # Se o usuário cancelar, retorna uma lista vazia
            return []
    return json_paths

def main():
    # Pede ao usuário para selecionar o número de arquivos JSON
    num_jsons = int(input("Digite o número de arquivos JSON que deseja processar (máximo 4): "))

    # Verifica se o número fornecido está dentro do intervalo permitido
    if num_jsons < 1 or num_jsons > 4:
        print("Por favor, digite um número entre 1 e 4.")
        return

    # Seleciona os arquivos JSON
    json_paths = select_json_files(num_jsons)

    # Se não houver arquivos selecionados
    if not json_paths:
        print("Nenhum arquivo selecionado.")
        return

    # Define o diretório de saída
    output_dir = 'output'

    # Processa cada arquivo JSON selecionado
    for json_path in json_paths:
        # Lê o JSON
        with open(json_path) as json_file:
            data = json.load(json_file)

        # Chama a função para gerar os arquivos
        generate_files_from_json(data, output_dir)
        print(f"Arquivos gerados com sucesso a partir de {json_path}.")

if __name__ == "__main__":
    main()
