A tool that reads your json, and generates the moves of your json, if you want to make a custom timeline, you can create your own name for your msm :)


_WORKS ONLY FOR JSON_



Tool Made By SquareJDBR