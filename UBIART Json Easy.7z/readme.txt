This tool is in the testing phase, only whoever I select will have access to it, it basically makes your json programming easier, calculates the ms, without you needing to spend a lot of time, for now, it only works on moves_0 but soon you will program one normal json too, make good use of it, if you have any questions, please contact me ;)

You Just Need MPC And Notepad++ to use this tool

SquareJDBR.