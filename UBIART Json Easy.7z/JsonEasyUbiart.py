import json
import keyboard

def calculate_duration(data, start_time, end_time):
    duration = 0
    goldmove = False
    
    for entry in data:
        if start_time <= entry["time"] <= end_time:
            duration += entry["duration"]
            goldmove = goldmove or entry["goldMove"]

    return duration, goldmove

def main():
    print("Welcome to JsonEasyUbiart By SquareJDBR")
    data = []

    try:
        while True:
            name = input("Enter the movement name (or press Esc to exit): ")
            if keyboard.is_pressed('Esc') or name.lower() == 'esc':
                break

            time = int(input("Enter the time: "))
            end_time = int(input("Enter the end time: "))
            goldmove = input("Is there a 'goldMove' movement (y/n)? ").lower() == 'y'

            data.append({
                "name": name,
                "time": time,
                "duration": end_time - time,  # Calculate duration based on start and end times
                "goldMove": 1 if goldmove else 0  # Replace True with 1, False with 0
            })

    except ValueError:
        print("Please enter valid values.")

    try:
        while True:
            start_time = int(input("Enter the start time (or press Esc to exit): "))
            if keyboard.is_pressed('Esc'):
                break

            end_time = int(input("Enter the end time: "))

            total_duration, goldmove = calculate_duration(data, start_time, end_time)

            print(f"\nTotal duration: {total_duration} milliseconds")

            if goldmove:
                goldmove_response = input("There is a 'goldMove' movement. Do you want to include it? (y/n): ").lower()
                if goldmove_response == 'y':
                    # Include the logic to handle 'goldMove' here
                    print("You chose to include the 'goldMove'.")
                else:
                    print("You chose not to include the 'goldMove'.")
            else:
                print("There is no 'goldMove' movement in this time range.")
                goldmove = 0

    except ValueError:
        print("Please enter valid times.")

    # Prompt the user for a codename
    codename = input("Enter a codename for the JSON file: ")

    # Save the result to a new JSON file with the provided codename
    with open(f'{codename}.json', 'w') as f:
        json.dump(data, f, indent=2, separators=(',', ': '))  # Add separators to include a comma after the number

if __name__ == "__main__":
    main()
