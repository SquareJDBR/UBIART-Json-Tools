import json

def main():
    print("Welcome to JsonEasyUbiart By SquareJDBR")
    data = []

    try:
        while True:
            name = input("Enter the movement name (type 'closeeeee' to exit): ")
            if name.lower() == 'closeeeee':
                break

            time = int(input("Enter the time: "))

            # Set a default duration of 500 milliseconds
            duration = 500

            data.append({
                "name": name,
                "time": time,
                "duration": duration
            })

    except ValueError:
        print("Please enter valid values.")

    # Prompt the user for a codename
    codename = input("Enter a codename for the JSON file: ")

    # Save the result to a new JSON file with the provided codename
    with open(f'{codename}.json', 'w') as f:
        json.dump(data, f, indent=2, separators=(',', ': '))  # Add separators to include a comma after the number

if __name__ == "__main__":
    main()
